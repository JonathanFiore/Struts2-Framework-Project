package Beans;

public class User {
	
	
	private String user;
	private String pass;
	private String mail;
	private boolean ps;
	
	
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public User()
	{
		
	}
	
	
	

	public boolean isPs() {
		return ps;
	}

	public void setPs(boolean ps) {
		this.ps = ps;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
	

}
