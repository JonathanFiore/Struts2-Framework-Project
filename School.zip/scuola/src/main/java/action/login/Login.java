package action.login;

import com.opensymphony.xwork2.ActionSupport;

public class Login extends ActionSupport{

	
	
	public Login()
	{
		
	}
	
	public String execute()
	{
		return SUCCESS;
	}
}
